import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

export const authOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  session: {
    strategy: "jwt", // pakai JWT
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        phone: { label: "Nomor HP", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const { phone, password } = credentials || {};
        if (!phone || !password) return null;

        // cari user berdasarkan phone
        const user = await prisma.user.findUnique({
          where: { phone },
        });
        if (!user) return null;

        // cek password hash
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) return null;

        // return data minimal
        return {
          id: user.id,
          name: user.nama,
          phone: user.phone,
          role: user.role, // penting!
          kelas: user.kelas, // opsional kalau ada
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      // Saat pertama login
      if (user) {
        token.id = user.id;
        token.role = user.role;
        token.kelas = user.kelas || null;
      }
      return token;
    },
    async session({ session, token }) {
      if (!session.user) session.user = {};
      session.user.id = token.id;
      session.user.role = token.role;
      session.user.kelas = token.kelas;
      return session;
    },
  },
};
