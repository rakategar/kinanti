import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs"; // gunakan 'bcrypt' jika Anda sudah menginstalnya

// Prisma singleton
const g = globalThis;
const prisma = g.__prisma || new PrismaClient({});
if (process.env.NODE_ENV !== "production") g.__prisma = prisma;

function normalizePhone(input = "") {
  const p = String(input).replace(/[^\d]/g, "");
  if (!p) return "";
  return p.startsWith("0") ? "62" + p.slice(1) : p; // 08… -> 628…
}

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: "Phone & Password",
      credentials: {
        phone: { label: "Phone", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(creds) {
        const phone = normalizePhone(creds?.phone || "");
        const password = String(creds?.password || "");

        // 1) Cari user by phone (pastikan di DB format 62…)
        const user = await prisma.user.findFirst({
          where: { phone },
          // 'password' di sini diasumsikan tersimpan SEBAGAI HASH (bcrypt)
          select: { id: true, nama: true, role: true, password: true },
        });
        if (!user) throw new Error("User not found");

        // 2) Bandingkan password plaintext vs hash
        //    - Jika Anda menggunakan 'bcrypt' (bukan 'bcryptjs'), import & gunakan sama: bcrypt.compare(...)
        const ok = await bcrypt.compare(password, user.password || "");
        if (!ok) throw new Error("Invalid password");

        // 3) Return user payload untuk NextAuth (WAJIB ada role)
        return {
          id: user.id,
          name: user.nama || "User",
          role: user.role, // "guru" | "siswa"
        };
      },
    }),
  ],

  session: { strategy: "jwt" },

  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role; // bawa role ke token
      }
      return token;
    },
    async session({ session, token }) {
      session.user.role = token.role; // expose ke client
      return session;
    },
  },

  pages: {
    signIn: "/login",
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
