// src/services/state.js
const prisma = require("../config/prisma");
const { normalizePhone } = require("../utils/phone");

async function getState(userPhone) {
  const key = normalizePhone(userPhone);
  const row = await prisma.conversationState
    .findUnique({ where: { userPhone: key } })
    .catch(() => null);
  if (!row) return null;
  return { lastIntent: row.lastIntent || null, slots: row.slots || {} };
}

async function setState(userPhone, state) {
  const key = normalizePhone(userPhone);
  await prisma.conversationState.upsert({
    where: { userPhone: key },
    update: { lastIntent: state.lastIntent || null, slots: state.slots || {} },
    create: {
      userPhone: key,
      lastIntent: state.lastIntent || null,
      slots: state.slots || {},
    },
  });
}

async function clearState(userPhone) {
  const key = normalizePhone(userPhone);
  await prisma.conversationState
    .delete({ where: { userPhone: key } })
    .catch(() => null);
}

module.exports = { getState, setState, clearState };
