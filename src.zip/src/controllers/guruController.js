// src/controllers/guruController.js
const prisma = require("../config/prisma");
const { MessageMedia } = require("whatsapp-web.js");
const { getState, setState, clearState } = require("../services/state");
const { normalizePhone } = require("../utils/phone");

// ===== Utils
async function getUserByPhone(phone) {
  return prisma.user.findUnique({ where: { phone } });
}
function ensureGuru(user) {
  const role = (user?.role || "").toString().toUpperCase();
  if (role !== "GURU") {
    const err = new Error("ROLE_FORBIDDEN");
    err.code = "ROLE_FORBIDDEN";
    throw err;
  }
}
const fmtWIB = (d) =>
  new Date(d).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

// ====== START wizard: kirim intro + FORM terpisah
async function handleGuruBuatPenugasan(message, { user, entities, waClient }) {
  let state = (await getState(user.phone)) || { lastIntent: null, slots: {} };

  const freshStart = state.lastIntent !== "guru_buat_penugasan";

  // set tanda wizard aktif
  state.lastIntent = "guru_buat_penugasan";

  // INIT hanya bila belum ada wizard berjalan
  if (freshStart || !state.slots) {
    state.slots = {
      kode: null,
      judul: null,
      deskripsi: null,
      lampirPdf: null, // 'ya' | 'tidak'
      deadlineHari: null, // integer (hari)
      kelas: entities.kelas || null,
    };
  } else {
    // kalau wizard sudah aktif, pertahankan slot yang sudah terisi
    // namun isi kelas dari entities bila sebelumnya masih null
    if (!state.slots.kelas && entities.kelas) {
      state.slots.kelas = entities.kelas;
    }
  }

  await setState(user.phone, state);

  // pesan 1: intro (tampilkan juga hint "ketik *simpan* / *batal*")
  await message.reply(
    "Mulai buat penugasan.\n" +
      "Ketik sesuai format berikut (boleh satu per satu).\n" +
      "Jika sudah lengkap, balas: *simpan* (atau *batal* untuk membatalkan)."
  );

  // pesan 2: FORM dengan nilai saat ini (kalau ada)
  const s = state.slots;
  const form = `- Kode: ${s.kode ?? ""}
- Judul: ${s.judul ?? ""}
- Deskripsi: ${s.deskripsi ?? ""}
- Lampirkan PDF (ya/tidak): ${s.lampirPdf ?? ""}
- Deadline: ${s.deadlineHari ?? "N"} (hari)
- Kelas: ${s.kelas ? `*${s.kelas}*` : "(ketik kelas, misal: XIITKJ2)"}`;

  return waClient.sendMessage(message.from, form);
}

// ====== Parser satu baris "Field: nilai" (dukung awalan "- ", toleransi label dg tanda kurung)
function parseWizardLine(line) {
  // Contoh baris valid:
  // "- Kode: RPL1"
  // "- Lampirkan PDF (ya/tidak): ya"
  // "- Kelas: XIITKJ2"
  const m = /^\s*-?\s*([a-zA-Z()[\]/ _-]+?)\s*:\s*(.+)\s*$/i.exec(line || "");
  if (!m) return null;

  // Normalisasi nama field:
  // 1) turunkan huruf
  // 2) buang isi dalam tanda kurung (contoh: "(ya/tidak)")
  // 3) rapikan spasi berlebih
  let fieldRaw = m[1].toLowerCase();
  fieldRaw = fieldRaw.replace(/\([^)]*\)/g, ""); // buang "(...)"
  fieldRaw = fieldRaw.replace(/\s+/g, " ").trim();

  const value = m[2].trim();

  const map = {
    kode: "kode",
    judul: "judul",
    deskripsi: "deskripsi",
    "lampirkan pdf": "lampirPdf",
    deadline: "deadlineHari",
    kelas: "kelas",
  };

  const field = map[fieldRaw];
  if (!field) return null;

  // Abaikan value placeholder generik seperti "(ketik kelas, misal: ...)"
  if (field === "kelas" && /^\(ketik\s+kelas[,)]/i.test(value)) {
    return null;
  }

  return { field, value };
}

// ====== Handler pesan selama wizard aktif (DUKUNG MULTILINE)
// (Pastikan tidak ada duplikat fungsi bernama sama di file ini)
async function handleGuruWizardMessage(message, { user }) {
  const state = await getState(user.phone);
  if (!state || state.lastIntent !== "guru_buat_penugasan") return false;

  const raw = message.body || "";
  console.log("Raw input:", raw);

  // Jika user mengetik "buat tugas" / "buat tugas baru" saat wizard aktif → tampilkan form/progress
  if (/^buat\s+tugas(\s+baru)?$/i.test(raw)) {
    const s = state.slots || {};
    const form = `- Kode: ${s.kode ?? ""}
- Judul: ${s.judul ?? ""}
- Deskripsi: ${s.deskripsi ?? ""}
- Lampirkan PDF (ya/tidak): ${s.lampirPdf ?? ""}
- Deadline: ${s.deadlineHari ?? "N"} (hari)
- Kelas: ${s.kelas ? `*${s.kelas}*` : "(ketik kelas, misal: XIITKJ2)"}`;
    await message.reply(
      "Ketik sesuai format berikut (boleh satu per satu).\n" +
        "Jika sudah lengkap, balas: *simpan* (atau *batal* untuk membatalkan)."
    );
    await message.reply(form);
    return true;
  }

  // Perintah khusus
  if (/^(batal|cancel)$/i.test(raw)) {
    await clearState(user.phone);
    await message.reply("❎ Pembuatan penugasan dibatalkan.");
    return true;
  }
  if (/^simpan$/i.test(raw)) {
    const s = state.slots || {};
    const missing = [];
    if (!s.kode) missing.push("Kode");
    if (!s.judul) missing.push("Judul");
    if (!s.deskripsi) missing.push("Deskripsi");
    if (!s.kelas || !/^(X|XI|XII)[A-Z]{2,8}\d{1,2}$/i.test(String(s.kelas))) {
      missing.push("Kelas");
    }

    if (missing.length) {
      await message.reply(
        `Field belum lengkap: ${missing.join(", ")}.\n` +
          "Lengkapi dulu, lalu ketik *simpan*."
      );
      return true;
    }

    // Deadline opsional → N hari dari sekarang
    let deadline = null;
    if (s.deadlineHari) {
      const n = parseInt(String(s.deadlineHari).replace(/\D/g, ""), 10);
      if (!isNaN(n) && n > 0) deadline = new Date(Date.now() + n * 86400000);
    }

    const created = await prisma.assignment.create({
      data: {
        kode: s.kode.toUpperCase(),
        judul: s.judul,
        deskripsi: s.deskripsi,
        deadline,
        kelas: (s.kelas || "").toUpperCase(),
        guruId: user.id,
      },
    });

    // Buat status untuk seluruh siswa target kelas
    const siswa = await prisma.user.findMany({
      where: { role: "SISWA", kelas: created.kelas },
    });
    if (siswa.length) {
      await prisma.assignmentStatus.createMany({
        data: siswa.map((st) => ({
          siswaId: st.id,
          tugasId: created.id,
          status: "BELUM_SELESAI",
        })),
        skipDuplicates: true,
      });
    }

    await clearState(user.phone);
    await message.reply(
      `✅ Tugas *${created.kode}* berhasil dibuat untuk kelas *${created.kelas}*.\n` +
        `Judul: ${created.judul}\n` +
        `Deadline: ${
          created.deadline
            ? new Date(created.deadline).toLocaleString("id-ID", {
                timeZone: "Asia/Jakarta",
              })
            : "Belum diatur"
        }\n\n` +
        `Untuk mengirim ke siswa: ketik *kirim ${created.kode} ${created.kelas}*`
    );
    return true;
  }

  // === Multiline: proses semua baris yang berbentuk "Field: nilai"
  const lines = raw.split(/\r?\n/);
  let updated = 0;
  let s = state.slots || {};

  for (const line of lines) {
    const parsed = parseWizardLine(line);
    console.log("Parsed line:", parsed);
    if (!parsed) continue;

    if (parsed.field === "kode") {
      // normalisasi kode → SERI-NUM (mtk123 → MTK-123)
      const m = /\b([a-z]{2,8})[-_]?(\d{1,4})\b/i.exec(parsed.value);
      if (!m) continue;
      s.kode = `${m[1].toUpperCase()}-${m[2]}`;
      updated++;
    } else if (parsed.field === "lampirPdf") {
      s.lampirPdf = /^(ya|yes|y)$/i.test(parsed.value) ? "ya" : "tidak";
      updated++;
    } else if (parsed.field === "deadlineHari") {
      const n = parseInt(parsed.value.replace(/\D/g, ""), 10);
      s.deadlineHari = isNaN(n) ? null : n;
      updated++;
    } else if (parsed.field === "kelas") {
      // parsed.value bisa "X TKJ 1" → normalkan
      const rawKelas = parsed.value;
      // Jika user tetap mengirim placeholder (aneh tapi bisa terjadi), skip
      if (!/^[()]/.test(rawKelas)) {
        s.kelas = rawKelas.replace(/\s+/g, "").toUpperCase(); // "X TKJ 1" -> "XTKJ1"
        updated++;
      }
    } else {
      // judul / deskripsi
      s[parsed.field] = parsed.value;
      updated++;
    }
  }

  if (updated > 0) {
    // gabungkan agar tidak menimpa slot lain
    await setState(user.phone, { ...state, slots: s });
    await message.reply(
      `✔️ ${updated} field disimpan. Ketik *simpan* jika sudah lengkap, atau lanjut isi field lain.`
    );
    return true;
  }

  // Tidak ada baris valid
  await message.reply(
    "Format tidak dikenali. Gunakan format: *Field: nilai* (misal: `Kode: BD-03`).\n" +
      "Contoh kirim sekaligus:\n" +
      "- Kode: MTK123\n- Judul: Tugas MTK\n- Deskripsi: …\n- Lampirkan PDF: ya\n- Deadline: 3\n- Kelas: XIITKJ2\n\n" +
      "Ketik *simpan* jika sudah lengkap atau *batal* untuk membatalkan."
  );
  return true;
}

// ===== Broadcast tugas (tetap ada)
async function handleGuruBroadcast(message, { entities, waClient }) {
  const { kode_tugas, kelas } = entities;
  if (!kode_tugas || !kelas) {
    return message.reply(
      'Butuh *kode_tugas* dan *kelas*. Contoh: "kirim tugas BD-03 untuk XIITKJ2".'
    );
  }

  const asg = await prisma.assignment.findUnique({
    where: { kode: kode_tugas },
  });
  if (!asg) return message.reply(`Kode tugas *${kode_tugas}* tidak ditemukan.`);

  const siswa = await prisma.user.findMany({ where: { role: "SISWA", kelas } });
  if (!siswa.length)
    return message.reply(`Tidak ada siswa di kelas *${kelas}*.`);

  const text =
    `*${asg.kode} — ${asg.judul}*\n` +
    `${asg.deskripsi || ""}\n` +
    (asg.deadline ? `Deadline: ${fmtWIB(asg.deadline)}\n` : "") +
    (asg.pdfUrl ? `Lampiran: ${asg.pdfUrl}` : "");

  for (const s of siswa) {
    const jid = `${s.phone}@c.us`;
    try {
      await waClient.sendMessage(jid, text);
    } catch (e) {
      console.error("broadcast fail to", jid, e.message);
    }
  }

  return message.reply(
    `Broadcast *${kode_tugas}* terkirim ke kelas *${kelas}* (${siswa.length} siswa).`
  );
}

// ===== Rekap excel (tetap ada)
async function handleGuruRekapExcel(message, { entities, excelUtil }) {
  const kelas = entities.kelas || null;
  const siswa = await prisma.user.findMany({
    where: { role: "SISWA", ...(kelas ? { kelas } : {}) },
    orderBy: { nama: "asc" },
  });
  if (!siswa.length)
    return message.reply(
      `Tidak ada siswa${kelas ? ` di kelas *${kelas}*` : ""}.`
    );

  const assignments = await prisma.assignment.findMany({
    ...(kelas ? { where: { kelas } } : {}),
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const rows = [];
  for (const st of await prisma.assignmentStatus.findMany({
    where: {
      siswaId: { in: siswa.map((s) => s.id) },
      tugasId: { in: assignments.map((a) => a.id) },
    },
    include: { tugas: true, siswa: true },
  })) {
    rows.push({
      Kelas: st.siswa.kelas || "-",
      Siswa: st.siswa.nama,
      Kode: st.tugas.kode,
      Judul: st.tugas.judul,
      Status: st.status,
    });
  }

  const buffer = await excelUtil.buildRekap(rows);
  const media = new MessageMedia(
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    buffer.toString("base64"),
    `rekap_${kelas || "all"}.xlsx`
  );
  await message.reply(media);
  return;
}

// ===== Entry point per pesan untuk fitur2 guru
async function handleGuruCommand(
  message,
  { waClient, entities, intent, excelUtil }
) {
  // Normalisasi nomor agar cocok dengan DB (62...) dan kunci state
  const fromJid = String(message.from || ""); // "62895xxxx@c.us"
  const from = fromJid.replace(/@c\.us$/i, ""); // "62895xxxx"
  const phoneKey = normalizePhone(from); // pastikan "62..."
  const user = await getUserByPhone(phoneKey);

  try {
    ensureGuru(user);
  } catch (e) {
    if (e.code === "ROLE_FORBIDDEN")
      return message.reply("Fitur ini khusus *Guru*.");
    throw e;
  }

  // >>> PRIORITAS WIZARD AKTIF <<<
  // Kalau user sedang di wizard buat penugasan,
  // JANGAN proses intent lain: selalu arahkan ke wizard.
  const currentState = await getState(user.phone);
  if (currentState?.lastIntent === "guru_buat_penugasan") {
    const handled = await handleGuruWizardMessage(message, { user });
    if (handled) return; // selesai di sini
  }

  // RAW TRIGGER: jika user mengetik "buat tugas" atau "buat tugas baru" tapi NLP meleset
  if (/^buat\s+tugas(\s+baru)?$/i.test(message.body || "")) {
    return handleGuruBuatPenugasan(message, { user, entities, waClient });
  }

  // Intent starter → mulai/ulang wizard (kirim intro + FORM)
  if (intent === "guru_buat_penugasan") {
    return handleGuruBuatPenugasan(message, { user, entities, waClient });
  }

  // Intent guru lain
  switch (intent) {
    case "guru_broadcast_tugas":
      return handleGuruBroadcast(message, { entities, waClient });

    case "guru_rekap_excel":
      return handleGuruRekapExcel(message, { entities, excelUtil });

    case "guru_list_siswa": {
      const kelas = entities.kelas || null;
      const list = await prisma.user.findMany({
        where: { role: "SISWA", ...(kelas ? { kelas } : {}) },
        orderBy: { nama: "asc" },
        take: 200,
      });
      if (!list.length)
        return message.reply(
          `Tidak ada siswa${kelas ? ` di kelas *${kelas}*` : ""}.`
        );
      const lines = list.map(
        (s, i) => `${i + 1}. ${s.nama} — ${s.kelas || "-"}`
      );
      return message.reply(
        `Daftar siswa${kelas ? ` ${kelas}` : ""}:\n` + lines.join("\n")
      );
    }

    default:
      return;
  }
}

module.exports = { handleGuruCommand };
