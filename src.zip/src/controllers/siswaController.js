// src/controllers/siswaController.js
// Fitur Siswa: daftar tugas, detail tugas, status tugas, dan kumpul tugas (unggah PDF ke Supabase)

const prismaMod = require("../config/prisma");
const prisma = prismaMod?.prisma ?? prismaMod?.default ?? prismaMod;
const { uploadPDFtoSupabase } = require("../utils/pdfUtils");

const PENDING = new Map();

function isGroupJid(jid = "") {
  return String(jid).endsWith("@g.us");
}
function phoneFromJid(jid = "") {
  return String(jid || "").replace(/@c\.us$/i, "");
}
function nowStamp() {
  return new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, "")
    .slice(0, 14);
}
function fmtDateWIB(d) {
  try {
    const date = d instanceof Date ? d : new Date(d);
    return date.toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return String(d || "-");
  }
}
function matchAny(text, arr) {
  const s = (text || "").toLowerCase();
  return arr.some((k) => s.includes(k));
}

async function getStudentBySender(senderJid) {
  const phone = phoneFromJid(senderJid);
  return prisma.user.findFirst({
    where: { phone, role: "siswa" },
  });
}

async function listOpenAssignments(student) {
  return prisma.assignmentStatus.findMany({
    where: { siswaId: student.id, status: "BELUM_SELESAI" },
    include: { tugas: { include: { guru: true } } },
  });
}

async function listSubmittedAssignments(student) {
  return prisma.assignmentStatus.findMany({
    where: { siswaId: student.id, status: "SELESAI" },
    include: { tugas: true },
  });
}

async function findAssignmentForStudentByKode(student, kode) {
  const tugas = await prisma.assignment.findFirst({
    where: { kode: kode.toUpperCase(), kelas: student.kelas },
    include: { guru: true },
  });
  if (!tugas) return null;
  const st = await prisma.assignmentStatus.findFirst({
    where: { tugasId: tugas.id, siswaId: student.id },
  });
  if (!st) return null;
  return { assignment: tugas, status: st };
}

async function beginSubmission(message, student, assignment) {
  const requirePdf = !!assignment.requirePdf || !!assignment.wajibPdf;
  PENDING.set(message.from, {
    step: "await_pdf",
    assignmentId: assignment.id,
    assignmentKode: assignment.kode,
    requirePdf,
  });

  const lampiran = assignment.pdfUrl
    ? `\n📎 Lampiran dari guru: ${assignment.pdfUrl}`
    : "";

  await message.reply(
    "📝 *Pengumpulan Tugas Baru!*\n" +
      `📌 Kode: *${assignment.kode}*\n` +
      `📖 Judul: *${assignment.judul}*\n` +
      `⏰ Deadline: ${fmtDateWIB(assignment.deadline)}\n` +
      lampiran +
      "\n\n👉 Kirim *PDF tugas* kamu di sini ya!" +
      (requirePdf ? " (PDF *wajib* 🔒)" : " (PDF opsional 😎)") +
      "\nKalau masih berupa foto, ketik *gambar ke pdf* dulu biar rapi ✨\n" +
      "_Ketik *batal* kalau mau cancel 🙅_"
  );
}

async function safeUpsertSubmission({ tugasId, siswaId, data }) {
  try {
    return await prisma.assignmentSubmission.upsert({
      where: { siswaId_tugasId: { siswaId, tugasId } },
      update: data,
      create: { tugasId, siswaId, ...data },
    });
  } catch (_) {
    try {
      return await prisma.assignmentSubmission.upsert({
        where: { tugasId_siswaId: { tugasId, siswaId } },
        update: data,
        create: { tugasId, siswaId, ...data },
      });
    } catch (_) {
      const existing = await prisma.assignmentSubmission.findFirst({
        where: { tugasId, siswaId },
        select: { id: true },
      });
      if (existing?.id) {
        return prisma.assignmentSubmission.update({
          where: { id: existing.id },
          data,
        });
      }
      return prisma.assignmentSubmission.create({
        data: { tugasId, siswaId, ...data },
      });
    }
  }
}

async function handleMediaWhilePending(message, pending, student) {
  const mimeGuess = message._data?.mimetype || message.mimetype || "";
  const isPdfLike =
    message.type === "document" ||
    message.hasMedia ||
    /^application\/pdf$/i.test(mimeGuess);

  if (!isPdfLike) return false;

  let media;
  try {
    media = await message.downloadMedia();
  } catch (e) {
    console.error("[siswaController] downloadMedia error:", e);
    await message.reply("😅 File gagal diambil, coba kirim ulang ya!");
    return true;
  }

  const mimetype = media?.mimetype || mimeGuess;
  if (!/application\/pdf/i.test(mimetype)) {
    await message.reply(
      "⚠️ Hanya boleh *PDF* ya. Kalau masih foto, ketik *gambar ke pdf* biar gampang 📸➡️📑"
    );
    return true;
  }

  try {
    const buffer = Buffer.from(media.data, "base64");
    const phone = phoneFromJid(message.from);
    const subdir = `users/siswa/${phone}/submissions`;
    const origName = message._data?.filename || media?.filename || "tugas.pdf";
    const safeName = origName.toLowerCase().endsWith(".pdf")
      ? origName
      : `${origName}.pdf`;
    const fileName = `${pending.assignmentKode}_${nowStamp()}_${safeName}`;

    const url = await uploadPDFtoSupabase(
      buffer,
      fileName,
      "application/pdf",
      subdir
    );

    await safeUpsertSubmission({
      tugasId: pending.assignmentId,
      siswaId: student.id,
      data: {
        fileUrl: url,
        fileName,
        submittedAt: new Date(),
        via: "whatsapp_document",
      },
    });

    await prisma.assignmentStatus.updateMany({
      where: { tugasId: pending.assignmentId, siswaId: student.id },
      data: { status: "SELESAI" },
    });

    PENDING.delete(message.from);
    await message.reply(
      "🎉 *Tugas sukses terkumpul!*\n" +
        `📌 Kode: *${pending.assignmentKode}*\n` +
        `📂 File: ${fileName}\n` +
        "Mantap! 🚀 Cek status dengan ketik *status tugas*."
    );
  } catch (e) {
    console.error("[siswaController] upload/DB error:", e);
    await message.reply("😢 Oops, gagal simpan tugas. Coba lagi ya!");
  }

  return true;
}

async function handleSiswaCommand(message, opts = {}) {
  try {
    if (isGroupJid(message.from)) {
      await message.reply(
        "👋 Halo! Fitur siswa cuma bisa dipakai di *chat pribadi*. DM aja ya 😉"
      );
      return;
    }

    if (!prisma || !prisma.user || !prisma.assignment) {
      console.warn("[siswaController] Prisma belum siap / salah ekspor.");
      await message.reply("⚠️ Database belum siap nih, sabar dulu ya 🙏");
      return;
    }

    const intent = opts.intent || "";
    const body = String(message.body || "").trim();
    const lbody = body.toLowerCase();

    const student = await getStudentBySender(message.from);
    if (!student) {
      await message.reply("📵 Nomor kamu belum terdaftar sebagai *siswa*. 🚫");
      return;
    }

    const pending = PENDING.get(message.from);
    if (pending) {
      if (lbody === "batal") {
        PENDING.delete(message.from);
        await message.reply("❌ Pengumpulan dibatalkan. 😌");
        return;
      }
      const handled = await handleMediaWhilePending(message, pending, student);
      if (handled) return;
      if (!message.hasMedia && body) {
        await message.reply(
          "📄 Ayo kirim *PDF tugas* kamu. Kalau masih foto, ketik *gambar ke pdf* dulu 📸➡️📑\n_Ketik *batal* untuk cancel._"
        );
        return;
      }
      return;
    }

    if (
      intent === "siswa_list_tugas" ||
      intent === "siswa_tugas_saya" ||
      matchAny(lbody, [
        "tugas saya",
        "daftar tugas",
        "tugas belum",
        "lihat tugas",
        "list tugas",
      ])
    ) {
      const rows = await listOpenAssignments(student);
      if (!rows.length) {
        await message.reply(
          "😎 Kamu bebas tugas, tidak ada yang belum selesai! 🎉"
        );
        return;
      }
      let resp = "📋 *Tugas Belum Selesai:*\n";
      for (const r of rows) {
        const t = r.tugas;
        resp +=
          `\n👉 ${t.kode} — ${t.judul}\n` +
          `   Guru: ${t.guru?.name || t.guru?.nama || "-"}\n` +
          `   Deadline: ${fmtDateWIB(t.deadline)}\n` +
          (t.pdfUrl ? `   Lampiran: ${t.pdfUrl}\n` : "") +
          `   Cara kumpul: ketik *kumpul ${t.kode}* lalu kirim PDF 📤`;
      }
      await message.reply(resp);
      return;
    }

    if (
      intent === "siswa_status" ||
      matchAny(lbody, ["status tugas", "status", "riwayat tugas", "riwayat"])
    ) {
      const rows = await listSubmittedAssignments(student);
      if (!rows.length) {
        await message.reply("🕐 Kamu belum kumpulin tugas apa pun.");
        return;
      }
      let resp = "✅ *Riwayat Tugas Selesai:*\n";
      for (const r of rows) {
        const t = r.tugas;
        resp += `\n✔️ ${t.kode} — ${t.judul}\n   Deadline: ${fmtDateWIB(
          t.deadline
        )}`;
      }
      await message.reply(resp);
      return;
    }

    if (intent === "siswa_detail_tugas") {
      const kode = (
        opts.entities?.kode ||
        opts.entities?.kode_tugas ||
        opts.entities?.assignmentCode ||
        ""
      )
        .toString()
        .trim()
        .toUpperCase();
      if (!kode) {
        await message.reply(
          "🤔 Format: *detail <KODE>* (contoh: _detail RPL-1_)"
        );
        return;
      }
      const found = await findAssignmentForStudentByKode(student, kode);
      if (!found) {
        await message.reply(`😕 Tugas dengan kode *${kode}* ga ketemu.`);
        return;
      }
      const t = found.assignment;
      await message.reply(
        "📖 *Detail Tugas:*\n" +
          `📌 Kode: *${t.kode}*\n` +
          `📝 Judul: *${t.judul}*\n` +
          `💬 Deskripsi: ${t.deskripsi || "-"}\n` +
          `⏰ Deadline: ${fmtDateWIB(t.deadline)}\n` +
          `🏫 Kelas: ${t.kelas}\n` +
          (t.pdfUrl ? `📎 Lampiran: ${t.pdfUrl}\n` : "")
      );
      return;
    }

    const md = lbody.match(/(?:detail|info)\s+([a-z0-9_-]+)/i);
    if (md) {
      const kode = md[1].toUpperCase();
      const found = await findAssignmentForStudentByKode(student, kode);
      if (!found) {
        await message.reply(`😕 Tugas dengan kode *${kode}* ga ketemu.`);
        return;
      }
      const t = found.assignment;
      await message.reply(
        "📖 *Detail Tugas:*\n" +
          `📌 Kode: *${t.kode}*\n` +
          `📝 Judul: *${t.judul}*\n` +
          `💬 Deskripsi: ${t.deskripsi || "-"}\n` +
          `⏰ Deadline: ${fmtDateWIB(t.deadline)}\n` +
          `🏫 Kelas: ${t.kelas}\n` +
          (t.pdfUrl ? `📎 Lampiran: ${t.pdfUrl}\n` : "")
      );
      return;
    }

    let kumpulKode = null;
    if (intent === "siswa_kumpul_tugas") {
      kumpulKode = (opts.entities?.kode || opts.entities?.assignmentCode || "")
        .toString()
        .trim();
    }
    if (!kumpulKode) {
      const m = lbody.match(/kumpul\s+([a-z0-9_-]+)/i);
      if (m) kumpulKode = m[1].toUpperCase();
    }
    if (kumpulKode) {
      const found = await findAssignmentForStudentByKode(student, kumpulKode);
      if (!found) {
        await message.reply(`😕 Tugas dengan kode *${kumpulKode}* ga ketemu.`);
        return;
      }
      await beginSubmission(message, student, found.assignment);
      return;
    }

    if (
      intent === "siswa_help" ||
      matchAny(lbody, ["bantuan", "help", "menu", "siswa"])
    ) {
      await message.reply(
        "📚 *Menu Siswa:*\n" +
          "✨ *tugas saya* — cek tugas belum selesai\n" +
          "✨ *status tugas* — lihat riwayat selesai\n" +
          "✨ *detail <KODE>* — detail tugas tertentu\n" +
          "✨ *kumpul <KODE>* — kumpulin tugas 📤\n" +
          "✨ *gambar ke pdf* — ubah foto jadi PDF ✨"
      );
      return;
    }

    await message.reply(
      "🤷 Perintah ga dikenali.\nKetik *menu* buat lihat opsi atau *kumpul <KODE>* buat kumpul tugas."
    );
  } catch (e) {
    console.error("handleSiswaCommand error:", e);
    await message.reply("😵 Aduh, ada error di fitur siswa. Coba lagi ya!");
  }
}

module.exports = { handleSiswaCommand };
